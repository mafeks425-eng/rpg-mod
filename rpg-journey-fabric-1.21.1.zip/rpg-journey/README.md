# RPG Journey (Fabric, Minecraft 1.21.1)
Сборка: установи JDK 21 и Gradle (или скопируй папку src в шаблон с https://fabricmc.net/develop/template/), затем `gradle build`.
Готовый jar: build/libs/rpg-journey-1.0.0.jar -> в папку mods (нужен Fabric API).
Команды: /rpg stats, /rpg up <str|vit|agi|mining|luck> [кол-во]
