package com.rpgjourney;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record RpgData(int level, int xp, int points, int str, int vit, int agi, int mining, int luck) {
    public static final int MAX_LEVEL = 100;
    public static final RpgData DEFAULT = new RpgData(1, 0, 0, 0, 0, 0, 0, 0);

    public static final Codec<RpgData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("level", 1).forGetter(RpgData::level),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(RpgData::xp),
            Codec.INT.optionalFieldOf("points", 0).forGetter(RpgData::points),
            Codec.INT.optionalFieldOf("str", 0).forGetter(RpgData::str),
            Codec.INT.optionalFieldOf("vit", 0).forGetter(RpgData::vit),
            Codec.INT.optionalFieldOf("agi", 0).forGetter(RpgData::agi),
            Codec.INT.optionalFieldOf("mining", 0).forGetter(RpgData::mining),
            Codec.INT.optionalFieldOf("luck", 0).forGetter(RpgData::luck)
    ).apply(i, RpgData::new));

    public int xpNeeded() {
        return 100 + (level - 1) * 50;
    }

    /** Добавляет опыт, повышает уровни. Каждый уровень = 1 очко навыков. */
    public RpgData addXp(int amount) {
        int lvl = level, x = xp + amount, pts = points;
        while (lvl < MAX_LEVEL && x >= 100 + (lvl - 1) * 50) {
            x -= 100 + (lvl - 1) * 50;
            lvl++;
            pts++;
        }
        if (lvl >= MAX_LEVEL) x = 0;
        return new RpgData(lvl, x, pts, str, vit, agi, mining, luck);
    }

    public static final int STAT_CAP = 20;

    public int get(String stat) {
        return switch (stat) {
            case "str" -> str;
            case "vit" -> vit;
            case "agi" -> agi;
            case "mining" -> mining;
            case "luck" -> luck;
            default -> -1;
        };
    }

    /** Тратит n очков на характеристику. Возвращает null, если нельзя. */
    public RpgData spend(String stat, int n) {
        int cur = get(stat);
        if (cur < 0 || n <= 0 || points < n || cur + n > STAT_CAP) return null;
        int p = points - n;
        return switch (stat) {
            case "str" -> new RpgData(level, xp, p, str + n, vit, agi, mining, luck);
            case "vit" -> new RpgData(level, xp, p, str, vit + n, agi, mining, luck);
            case "agi" -> new RpgData(level, xp, p, str, vit, agi + n, mining, luck);
            case "mining" -> new RpgData(level, xp, p, str, vit, agi, mining + n, luck);
            default -> new RpgData(level, xp, p, str, vit, agi, mining, luck + n);
        };
    }
}
