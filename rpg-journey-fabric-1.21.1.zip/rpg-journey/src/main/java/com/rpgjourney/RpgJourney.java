package com.rpgjourney;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.Monster;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;

public class RpgJourney implements ModInitializer {
    public static final String MOD_ID = "rpgjourney";
    private static final List<String> STATS = List.of("str", "vit", "agi", "mining", "luck");

    public static final AttachmentType<RpgData> DATA = AttachmentRegistry.<RpgData>builder()
            .persistent(RpgData.CODEC)
            .copyOnDeath()
            .initializer(() -> RpgData.DEFAULT)
            .buildAndRegister(Identifier.of(MOD_ID, "data"));

    private static final Identifier ID_STR = Identifier.of(MOD_ID, "str");
    private static final Identifier ID_VIT = Identifier.of(MOD_ID, "vit");
    private static final Identifier ID_AGI = Identifier.of(MOD_ID, "agi");
    private static final Identifier ID_MINE = Identifier.of(MOD_ID, "mining");
    private static final Identifier ID_LUCK = Identifier.of(MOD_ID, "luck");

    @Override
    public void onInitialize() {
        // Опыт за убийство мобов
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity player && entity != player) {
                int xp = entity instanceof Monster
                        ? Math.max(5, (int) entity.getMaxHealth())
                        : 1;
                giveXp(player, xp);
            }
        });

        // Опыт за добычу
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (!(player instanceof ServerPlayerEntity sp)) return;
            int xp;
            if (state.isIn(ConventionalBlockTags.ORES)) xp = 5;
            else if (state.isIn(BlockTags.LOGS)) xp = 2;
            else if (state.isIn(BlockTags.PICKAXE_MINEABLE)) xp = 1;
            else return;
            giveXp(sp, xp);
        });

        // Применение характеристик
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> applyStats(handler.player));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> applyStats(newP));

        // Команды
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> dispatcher.register(
                CommandManager.literal("rpg")
                        .then(CommandManager.literal("stats").executes(ctx -> {
                            showStats(ctx.getSource().getPlayerOrThrow());
                            return 1;
                        }))
                        .then(CommandManager.literal("up")
                                .then(CommandManager.argument("stat", StringArgumentType.word())
                                        .suggests((c, b) -> CommandSource.suggestMatching(STATS, b))
                                        .executes(ctx -> spend(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "stat"), 1))
                                        .then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 20))
                                                .executes(ctx -> spend(ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "stat"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"))))))
        ));
    }

    public static void giveXp(ServerPlayerEntity p, int amount) {
        RpgData old = p.getAttachedOrElse(DATA, RpgData.DEFAULT);
        RpgData now = old.addXp(amount);
        p.setAttached(DATA, now);
        if (now.level() > old.level()) {
            p.sendMessage(Text.literal("★ Уровень " + now.level() + "! Очков навыков: " + now.points()
                    + " — трать: /rpg up <str|vit|agi|mining|luck>").formatted(Formatting.GOLD), false);
            p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP,
                    SoundCategory.PLAYERS, 1f, 1f);
        } else {
            p.sendMessage(Text.literal("+" + amount + " XP  (" + now.xp() + "/" + now.xpNeeded() + ")  ур. "
                    + now.level()).formatted(Formatting.GREEN), true);
        }
    }

    private static int spend(ServerCommandSource src, String stat, int n) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity p = src.getPlayerOrThrow();
        RpgData d = p.getAttachedOrElse(DATA, RpgData.DEFAULT);
        if (d.get(stat) < 0) {
            src.sendError(Text.literal("Неизвестная характеристика. Доступно: str, vit, agi, mining, luck"));
            return 0;
        }
        RpgData nd = d.spend(stat, n);
        if (nd == null) {
            src.sendError(Text.literal("Не хватает очков или достигнут максимум (" + RpgData.STAT_CAP + ")."));
            return 0;
        }
        p.setAttached(DATA, nd);
        applyStats(p);
        src.sendFeedback(() -> Text.literal("Прокачано: " + stat + " → " + nd.get(stat)
                + "  (осталось очков: " + nd.points() + ")").formatted(Formatting.AQUA), false);
        return 1;
    }

    private static void showStats(ServerPlayerEntity p) {
        RpgData d = p.getAttachedOrElse(DATA, RpgData.DEFAULT);
        p.sendMessage(Text.literal("═ RPG Journey ═").formatted(Formatting.GOLD), false);
        p.sendMessage(Text.literal("Уровень " + d.level() + "  XP " + d.xp() + "/" + d.xpNeeded()
                + "  Очков: " + d.points()), false);
        p.sendMessage(Text.literal("⚔ str (урон +0.5): " + d.str()), false);
        p.sendMessage(Text.literal("❤ vit (здоровье +1 сердце): " + d.vit()), false);
        p.sendMessage(Text.literal("➤ agi (скорость +2%): " + d.agi()), false);
        p.sendMessage(Text.literal("⛏ mining (скорость добычи +10%): " + d.mining()), false);
        p.sendMessage(Text.literal("☘ luck (удача +0.5): " + d.luck()), false);
    }

    public static void applyStats(ServerPlayerEntity p) {
        RpgData d = p.getAttachedOrElse(DATA, RpgData.DEFAULT);
        mod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, ID_STR, d.str() * 0.5, Operation.ADD_VALUE);
        mod(p, EntityAttributes.GENERIC_MAX_HEALTH, ID_VIT, d.vit() * 2.0, Operation.ADD_VALUE);
        mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, ID_AGI, d.agi() * 0.02, Operation.ADD_MULTIPLIED_BASE);
        mod(p, EntityAttributes.PLAYER_BLOCK_BREAK_SPEED, ID_MINE, d.mining() * 0.1, Operation.ADD_MULTIPLIED_BASE);
        mod(p, EntityAttributes.GENERIC_LUCK, ID_LUCK, d.luck() * 0.5, Operation.ADD_VALUE);
    }

    private static void mod(LivingEntity e, RegistryEntry<EntityAttribute> attr, Identifier id, double v, Operation op) {
        EntityAttributeInstance inst = e.getAttributeInstance(attr);
        if (inst == null) return;
        inst.removeModifier(id);
        if (v != 0) inst.addTemporaryModifier(new EntityAttributeModifier(id, v, op));
    }
}
