package com.rpgjourney;

import com.rpgjourney.registry.ModArmorMaterials;
import com.rpgjourney.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(RpgJourney.MOD_ID)
public final class RpgJourney {
    public static final String MOD_ID = "rpg_journey";\n\n    public static ResourceLocation id(String path) {\n        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);\n    }

    public RpgJourney(IEventBus modEventBus) {
        ModArmorMaterials.ARMOR_MATERIALS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModItems.CREATIVE_TABS.register(modEventBus);
    }
}
