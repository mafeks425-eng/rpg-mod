package com.rpgjourney.registry;

import com.rpgjourney.RpgJourney;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ArmorItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import java.util.List;
import java.util.Map;

public final class ModArmorMaterials {
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, RpgJourney.MOD_ID);

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> KNIGHT =
            ARMOR_MATERIALS.register("knight", () -> new ArmorMaterial(
                    Map.of(ArmorItem.Type.HELMET, 3, ArmorItem.Type.CHESTPLATE, 8,
                            ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.BOOTS, 3),
                    18,
                    SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(net.minecraft.world.item.Items.IRON_INGOT),
                    List.of(new ArmorMaterial.Layer(RpgJourney.id("knight"))),
                    2.0F, 0.05F
            ));

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> FLAME =
            ARMOR_MATERIALS.register("flame", () -> new ArmorMaterial(
                    Map.of(ArmorItem.Type.HELMET, 3, ArmorItem.Type.CHESTPLATE, 8,
                            ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.BOOTS, 3),
                    22,
                    SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(net.minecraft.world.item.Items.BLAZE_POWDER),
                    List.of(new ArmorMaterial.Layer(RpgJourney.id("flame"))),
                    3.0F, 0.10F
            ));

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> FROST =
            ARMOR_MATERIALS.register("frost", () -> new ArmorMaterial(
                    Map.of(ArmorItem.Type.HELMET, 3, ArmorItem.Type.CHESTPLATE, 8,
                            ArmorItem.Type.LEGGINGS, 6, ArmorItem.Type.BOOTS, 3),
                    24,
                    SoundEvents.ARMOR_EQUIP_NETHERITE,
                    () -> Ingredient.of(net.minecraft.world.item.Items.BLUE_ICE),
                    List.of(new ArmorMaterial.Layer(RpgJourney.id("frost"))),
                    3.5F, 0.12F
            ));

    private ModArmorMaterials() {}
}
