package com.rpgjourney.registry;

import com.rpgjourney.RpgJourney;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RpgJourney.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RpgJourney.MOD_ID);

    // Legendary weapons
    public static final DeferredHolder<Item, Item> SKELETON_KING_BLADE = ITEMS.register(
            "skeleton_king_blade", () -> weapon(9.0, -2.4, Rarity.EPIC));
    public static final DeferredHolder<Item, Item> EMBER_AXE = ITEMS.register(
            "ember_axe", () -> weapon(10.0, -3.0, Rarity.LEGENDARY));
    public static final DeferredHolder<Item, Item> FROST_SPEAR = ITEMS.register(
            "frost_spear", () -> weapon(8.0, -2.2, Rarity.EPIC));
    public static final DeferredHolder<Item, Item> ARCANE_STAFF = ITEMS.register(
            "arcane_staff", () -> weapon(6.0, -1.8, Rarity.RARE));
    public static final DeferredHolder<Item, Item> SHADOW_DAGGER = ITEMS.register(
            "shadow_dagger", () -> weapon(6.5, -1.2, Rarity.RARE));

    // Knight armor
    public static final DeferredHolder<Item, Item> KNIGHT_HELMET = armor("knight_helmet", ModArmorMaterials.KNIGHT, ArmorItem.Type.HELMET);
    public static final DeferredHolder<Item, Item> KNIGHT_CHESTPLATE = armor("knight_chestplate", ModArmorMaterials.KNIGHT, ArmorItem.Type.CHESTPLATE);
    public static final DeferredHolder<Item, Item> KNIGHT_LEGGINGS = armor("knight_leggings", ModArmorMaterials.KNIGHT, ArmorItem.Type.LEGGINGS);
    public static final DeferredHolder<Item, Item> KNIGHT_BOOTS = armor("knight_boots", ModArmorMaterials.KNIGHT, ArmorItem.Type.BOOTS);

    // Flame armor
    public static final DeferredHolder<Item, Item> FLAME_HELMET = armor("flame_helmet", ModArmorMaterials.FLAME, ArmorItem.Type.HELMET);
    public static final DeferredHolder<Item, Item> FLAME_CHESTPLATE = armor("flame_chestplate", ModArmorMaterials.FLAME, ArmorItem.Type.CHESTPLATE);
    public static final DeferredHolder<Item, Item> FLAME_LEGGINGS = armor("flame_leggings", ModArmorMaterials.FLAME, ArmorItem.Type.LEGGINGS);
    public static final DeferredHolder<Item, Item> FLAME_BOOTS = armor("flame_boots", ModArmorMaterials.FLAME, ArmorItem.Type.BOOTS);

    // Frost armor
    public static final DeferredHolder<Item, Item> FROST_HELMET = armor("frost_helmet", ModArmorMaterials.FROST, ArmorItem.Type.HELMET);
    public static final DeferredHolder<Item, Item> FROST_CHESTPLATE = armor("frost_chestplate", ModArmorMaterials.FROST, ArmorItem.Type.CHESTPLATE);
    public static final DeferredHolder<Item, Item> FROST_LEGGINGS = armor("frost_leggings", ModArmorMaterials.FROST, ArmorItem.Type.LEGGINGS);
    public static final DeferredHolder<Item, Item> FROST_BOOTS = armor("frost_boots", ModArmorMaterials.FROST, ArmorItem.Type.BOOTS);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RPG_TAB = CREATIVE_TABS.register(
            "rpg_items", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rpg_journey"))
                    .icon(() -> new ItemStack(SKELETON_KING_BLADE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(SKELETON_KING_BLADE.get());
                        output.accept(EMBER_AXE.get());
                        output.accept(FROST_SPEAR.get());
                        output.accept(ARCANE_STAFF.get());
                        output.accept(SHADOW_DAGGER.get());
                        output.accept(KNIGHT_HELMET.get());
                        output.accept(KNIGHT_CHESTPLATE.get());
                        output.accept(KNIGHT_LEGGINGS.get());
                        output.accept(KNIGHT_BOOTS.get());
                        output.accept(FLAME_HELMET.get());
                        output.accept(FLAME_CHESTPLATE.get());
                        output.accept(FLAME_LEGGINGS.get());
                        output.accept(FLAME_BOOTS.get());
                        output.accept(FROST_HELMET.get());
                        output.accept(FROST_CHESTPLATE.get());
                        output.accept(FROST_LEGGINGS.get());
                        output.accept(FROST_BOOTS.get());
                    }).build());

    private static Item weapon(double damage, double speed, Rarity rarity) {
        ItemAttributeModifiers attributes = ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(RpgJourney.id("weapon_damage"), damage, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED,
                        new AttributeModifier(RpgJourney.id("weapon_speed"), speed, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .build();
        return new Item(new Item.Properties().stacksTo(1).rarity(rarity).attributes(attributes));
    }

    private static DeferredHolder<Item, Item> armor(
            String name,
            DeferredHolder<net.minecraft.world.item.ArmorMaterial, net.minecraft.world.item.ArmorMaterial> material,
            ArmorType type) {
        return ITEMS.register(name, () -> new ArmorItem(material, type, new Item.Properties().rarity(Rarity.RARE)));
    }

    private ModItems() {}
}
