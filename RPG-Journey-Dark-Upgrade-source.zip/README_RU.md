# RPG Journey: Dark Upgrade (Fabric 1.21.1)

В проект включён исходный `rpg-journey-original.jar`: базовая RPG-система не удаляется, поверх неё добавляются:
- тёмное меню по клавише **R**;
- вкладки статуса, навыков и боссов;
- три команды призыва боссов с оружием: `/rpgboss spawn skeleton_king`, `flame_lord`, `ice_dragon`.

## Сборка
Требуются JDK 21 и Gradle 8.10+:
```bash
gradle build
```
Готовый JAR появится в `build/libs/rpg-journey-dark-1.1.0.jar`.

## Установка
Скопируй итоговый JAR в `mods` на сервер и клиент. Нужны Fabric Loader, Fabric API и Minecraft 1.21.1.

Примечание: меню использует существующие серверные команды `/rpg stats` и `/rpg up <stat> <amount>` исходного мода. Боссы — новые серверные сущности на базе ванильных мобов с экипировкой и усиленными характеристиками.
