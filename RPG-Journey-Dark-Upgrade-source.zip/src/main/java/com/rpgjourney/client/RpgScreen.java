package com.rpgjourney.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class RpgScreen extends Screen {
    private int tab = 0;
    public RpgScreen() { super(Text.literal("RPG Journey")); }

    @Override protected void init() { build(); }
    private void build() {
        clearChildren();
        int left = width/2 - 150, top = height/2 - 105;
        addDrawableChild(ButtonWidget.builder(Text.literal("Статус"), b -> {tab=0;build();})
            .dimensions(left, top, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Навыки"), b -> {tab=1;build();})
            .dimensions(left+102, top, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Боссы"), b -> {tab=2;build();})
            .dimensions(left+204, top, 96, 20).build());
        if (tab == 0) {
            addDrawableChild(cmd("Характеристики / опыт", "/rpg stats", left, top+42));
            addDrawableChild(cmd("+ Сила", "/rpg up str 1", left, top+68));
            addDrawableChild(cmd("+ Живучесть", "/rpg up vit 1", left, top+94));
            addDrawableChild(cmd("+ Ловкость", "/rpg up agi 1", left, top+120));
            addDrawableChild(cmd("+ Горное дело", "/rpg up mining 1", left+154, top+68));
            addDrawableChild(cmd("+ Удача", "/rpg up luck 1", left+154, top+94));
        } else if (tab == 1) {
            addDrawableChild(cmd("Распределить силу", "/rpg up str 1", left, top+48));
            addDrawableChild(cmd("Распределить защиту", "/rpg up vit 1", left, top+76));
            addDrawableChild(cmd("Распределить скорость", "/rpg up agi 1", left, top+104));
            addDrawableChild(cmd("Показать мои параметры", "/rpg stats", left, top+132));
        } else {
            addDrawableChild(cmd("Призвать Короля скелетов", "/rpgboss spawn skeleton_king", left, top+48));
            addDrawableChild(cmd("Призвать Повелителя пламени", "/rpgboss spawn flame_lord", left, top+78));
            addDrawableChild(cmd("Призвать Ледяного дракона", "/rpgboss spawn ice_dragon", left, top+108));
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
            .dimensions(left+204, top+158, 96, 20).build());
    }
    private ButtonWidget cmd(String label, String command, int x, int y) {
        return ButtonWidget.builder(Text.literal(label), b -> {
            if (client != null && client.getNetworkHandler() != null)
                client.getNetworkHandler().sendChatCommand(command.substring(1));
        }).dimensions(x,y,146,22).build();
    }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int x=width/2-165, y=height/2-125;
        ctx.fill(x,y,x+330,y+250,0xF0181217);
        ctx.fill(x,y,x+330,y+3,0xFF8B2635);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("RPG JOURNEY").formatted(Formatting.GOLD,Formatting.BOLD), width/2,y+12,0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("DARK FANTASY • FABRIC 1.21.1").formatted(Formatting.GRAY), width/2,y+27,0xAAAAAA);
        if(tab==0) {
            ctx.drawTextWithShadow(textRenderer, "Управление персонажем", x+16,y+67,0xFFD9C28A);
            ctx.drawTextWithShadow(textRenderer, "Открой /rpg stats для просмотра уровня и XP.", x+16,y+91,0xFFE0D8D0);
            ctx.drawTextWithShadow(textRenderer, "Очки навыков распределяются командами ниже.", x+16,y+105,0xFFB7AEB0);
        } else if(tab==1) {
            ctx.drawTextWithShadow(textRenderer, "Каждое нажатие тратит 1 очко навыка.", x+16,y+67,0xFFE0D8D0);
            ctx.drawTextWithShadow(textRenderer, "Максимум характеристик — 20 (как в базовой RPG).", x+16,y+84,0xFFB7AEB0);
        } else {
            ctx.drawTextWithShadow(textRenderer, "Боссы появляются рядом с тобой.", x+16,y+67,0xFFE0D8D0);
            ctx.drawTextWithShadow(textRenderer, "Они усилены и держат уникальное оружие.", x+16,y+84,0xFFB7AEB0);
        }
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public boolean shouldPause() { return false; }
}
