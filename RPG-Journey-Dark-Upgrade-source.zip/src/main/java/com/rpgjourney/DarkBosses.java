package com.rpgjourney;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.mob.PiglinBruteEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

public class DarkBosses implements ModInitializer {
    @Override public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("rpgboss")
                .then(CommandManager.literal("spawn")
                    .then(CommandManager.argument("boss", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            builder.suggest("skeleton_king"); builder.suggest("flame_lord"); builder.suggest("ice_dragon");
                            return builder.buildFuture();
                        }).executes(ctx -> spawn(ctx.getSource().getPlayerOrThrow(),
                            StringArgumentType.getString(ctx, "boss"))))));
    }

    private static int spawn(ServerPlayerEntity player, String id) {
        World world = player.getWorld();
        Entity boss;
        String title;
        ItemStack weapon;
        if (id.equals("skeleton_king")) {
            WitherSkeletonEntity e = (WitherSkeletonEntity) net.minecraft.entity.EntityType.WITHER_SKELETON.create(world);\n            if (e == null) return 0;
            title = "Король скелетов"; weapon = new ItemStack(Items.NETHERITE_SWORD);
            e.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
            e.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
            e.setHealth( e.getMaxHealth() ); boss = e;
        } else if (id.equals("flame_lord")) {
            PiglinBruteEntity e = (PiglinBruteEntity) net.minecraft.entity.EntityType.PIGLIN_BRUTE.create(world);\n            if (e == null) return 0;
            title = "Повелитель пламени"; weapon = new ItemStack(Items.NETHERITE_AXE);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 20*60*20, 0));
            e.setHealth(e.getMaxHealth()); boss = e;
        } else if (id.equals("ice_dragon")) {
            WitherEntity e = (WitherEntity) net.minecraft.entity.EntityType.WITHER.create(world);\n            if (e == null) return 0;
            title = "Ледяной дракон"; weapon = new ItemStack(Items.TRIDENT);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20*60*20, 0));
            e.setHealth(e.getMaxHealth()); boss = e;
        } else {
            player.sendMessage(Text.literal("Неизвестный босс. Используй skeleton_king, flame_lord или ice_dragon."), false);
            return 0;
        }
        boss.setCustomName(Text.literal("☠ " + title + " ☠").formatted(Formatting.DARK_RED, Formatting.BOLD));
        boss.setCustomNameVisible(true);
        boss.setGlowing(true);
        boss.setPersistent();
        if (boss instanceof net.minecraft.entity.LivingEntity living) {
            living.equipStack(EquipmentSlot.MAINHAND, weapon);
            living.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(
                id.equals("ice_dragon") ? 300.0 : 180.0);
            living.setHealth(living.getMaxHealth());
            living.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(
                id.equals("skeleton_king") ? 18.0 : 22.0);
            living.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.32);
        }
        boss.refreshPositionAndAngles(player.getX()+3, player.getY(), player.getZ()+3, player.getYaw(), 0);
        world.spawnEntity(boss);
        player.sendMessage(Text.literal("Босс призван: " + title).formatted(Formatting.GOLD), false);
        return 1;
    }
}
